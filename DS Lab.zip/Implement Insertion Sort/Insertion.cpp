#include<iostream>
using namespace std;

int main()
{
    int x,y,n,temp,a[20];
    cout<<"Enter the total elements: ";
    cin>>n;
    cout<<"Now enter the elements";

    for(x=0;x<n;x++)
    {
        cin>>a[x];
    }

    for(x=1;x<=n-1;x++)
    {
        temp=a[x];
        y=x-1;


    while((temp<a[y])&&(y>=0))
    {
        a[y+1]=a[y];
        y=y-1;
    }

        a[y+1]=temp;
    }

    cout<<"The Sorted list is";

    for(x=0;x<n;x++)
    {
        cout<<a[x]<<" ";
    }

    return 0;
}
