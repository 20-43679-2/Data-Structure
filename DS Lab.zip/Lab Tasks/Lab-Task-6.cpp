void insertNodeAtFirst(int data)
{
Node *newNode = new Node();
newNode->data = data;
newNode->nextNode = NULL;



if (isEmpty())
{
firstNode = newNode;
lastNode = newNode;
}
else
{
newNode->nextNode = firstNode;
firstNode = newNode;
}
}



void insertNodeAtLast(int data)
{
Node *newNode = new Node();
newNode->data = data;
newNode->nextNode = NULL;



if (isEmpty())
{
firstNode = newNode;
lastNode = newNode;
}
else
{
lastNode->nextNode = newNode;
lastNode = newNode;
}
}



void insertNodeInMiddle(int index, int data)
{ index=index-1;
Node *newNode = new Node();
newNode->data = data;
newNode->nextNode = NULL;



int i = 0;
currentNode = firstNode;
while (currentNode != NULL && i < index)
{
i++;
currentNode = currentNode->nextNode;
}



newNode->nextNode = currentNode->nextNode;
currentNode->nextNode = newNode;
}



void deleteNodeAtFirst()
{
firstNode = firstNode->nextNode;
}



void deleteNodeAtLast()
{
currentNode = firstNode;
while (currentNode->nextNode != lastNode)
{
currentNode = currentNode->nextNode;
}
lastNode = currentNode;
lastNode->nextNode = NULL;



}



void deleteNodeInMiddle(int index)
{
int i = 0;
currentNode = firstNode;
while (currentNode != NULL && i < index - 1)
{
i++;
currentNode = currentNode->nextNode;
}



currentNode->nextNode = (currentNode->nextNode)->nextNode;
