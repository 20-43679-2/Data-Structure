#include<iostream>
using namespace std;

{
    int Stock[100], Top=0, MaxSize

    bool isEmpty(){
    return (Top==0);
    }
    bool isFull(){
    return (Top==MaxSize);
    }
    bool push (int Element){
    if (isFull())
    {
        cout << "Stack is Full\n" return false;
    }
    Stack[Top++]=Element;
    return true;
    }
    bool pop(){
    if(isEmpty())
    {
        cout<<
    }
    }
}
