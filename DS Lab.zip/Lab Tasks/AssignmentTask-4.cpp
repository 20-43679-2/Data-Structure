#include <iostream>
using namespace std;

int myStack[100], n=100, top=-1;


void push(int item)
{
   if(top>=n-1)
   cout<<"Stack Overflow"<<endl;

   else
   {
      top++;
      myStack[top]=item;
   }
}

void pop()
{
   if(top<=-1)
   cout<<"Stack Underflow"<<endl;
   else
   {
      cout<<"The top element "<< myStack[top]<<" is poped." <<endl;
      top--;
   }
}

void getTopElement()
{
   if(top<=-1)
   cout<<"Stack Underflow"<<endl;
   else
   {
      cout<<"The top element "<< myStack[top]<<endl;
   }
}

void print()
{
   if(top>=0)
   {
      cout<<"Showing elements:";
      for(int i=top; i>=0; i--)
      {
        cout<<myStack[i]<<" ";
      }
      cout<<endl;
   }
   else
    cout<<"Stack is empty";
}

void evaluateExpression()
{
    //pass
    cout<<"what to do ??"<<endl;
}

void IsEmpty()
{
     if(top==-1)
        cout<<"Stack is empty"<<endl;
     else
        cout<<"Stack is not empty"<<endl;
}

void IsFull()
{
     if(top==n-1)
        cout<<"Stack is full"<<endl;
     else
        cout<<"Stack is not full"<<endl;
}

int main( )
{
	//declare necessary variables and objects
	bool repeat = true;
	while(repeat==true)
	{
		cout<<"What do you want?"<<endl<<endl;
		cout<<"1. Push an Element"<<endl;
		cout<<"2. Pop an Element"<<endl;
		cout<<"3. Get the top Element"<<endl;
		cout<<"4. Print the stack"<<endl;
		cout<<"5. Convert to Postfix"<<endl;
		cout<<"6. Check array is empty"<<endl;
		cout<<"7. Check array is full"<<endl;
		cout<<"8. Exit"<<endl;

		int choice;
		cin>>choice;

		switch(choice)
		{
			case 1:
				int a;
                cout<<"Please input a number: ";
                cin>>a;
				push(a);
				break;

			case 2:

				pop();
				break;

			case 3:

				getTopElement();
				break;

			case 4:

				print();
				break;

			case 5:

				evaluateExpression();
				break;

			case 6:

				IsEmpty();
				break;

			case 7:

				IsFull();
				break;

			case 8:

				repeat = false;
				cout<<"You have choose to Exit...."<<endl;
				break;

			default:

				cout<<"Invalid Choice..."<<endl;
				break;
		}
	}
}
