#include<iostream>
using namespace std;

int main()
{
int n;

cout<<"Enter the array size: "<<endl;
cin>>n;

int arr[n];

for(int i=0; i<n; i++)
{
cout<<"Enter array element: "<<endl;
cin>>arr[i];
}

int smallest=arr[0];
for(int i=0; i<n; i++)
{
if(smallest>arr[i])
{
smallest=arr[i];
}
}

cout<<"Smallest Element is: "<<smallest;

return 0;

}
