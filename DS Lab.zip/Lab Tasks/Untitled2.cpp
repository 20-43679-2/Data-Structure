#include<iostream>
using namespace std;

int main ()
{
    int soa;
    int arr[soa];
    int i, size, odd=0, even=0;

    cout<<"Enter the size of array: "<<endl;
    cin>>soa;

   for(int i=0;i<soa; i++)
    {
        if(arr[i]%2==0)
        {
            even++;
        }
        else if(arr[i]%2 != 0)
            {odd++;}
    }

  int e[even];
  int o[odd];
  int ioe=0;
  int ioo=0;

         for(int i=0;i<soa; i++)
    {
        if(arr[i]%2==0)
        {
            e[ioe] = arr[i];
            e[ioe]++;


        }
        else if(arr[i]%2 != 0)
            {
                o[ioo] = arr[i];
                o[ioo]++;


            }
    }

   cout<<"Even: "<<endl;

    for(int i = 0; i<soa; i++)
    {
        cout<<e[ioe]<<"  ";
    }
    cout<<endl;

    cout<<"ODD: "<<endl;

    for(int i = 0; i<soa; i++)
    {
        cout<<o[ioo]<<"  ";
    }
    cout<<endl;
}
