#include<iostream>
using namespace std;

int main ()
{
    int soa;
    int arr[soa];
    int i, size, odd=0, even=0;

    cout<<"Enter the size of array: "<<endl;
    cin>>soa;

    for (int i=0; i<soa; i++)
    {
        cin>>arr[i];
    }

    for (int i=0; i<soa; i++)
    {
        if(arr[i]%2==0)

        {
            cout<<"The number is even"<<endl;
        }

        else
        {
            cout<<"The number is odd"<<endl;
        }
    }
}
