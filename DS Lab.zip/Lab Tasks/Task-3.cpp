#include <iostream>
using namespace std;

int main()
{
    int f,l;

    cout<<"Enter the First Number: "<<endl;
    cin>>f;

    cout<<"Enter the Last Number: "<<endl;
    cin>>l;

    for(int i=f; i<=l; i++)
        {
        if(i%2!=0)
        {
        cout<<i<<endl;
        }

        }
 return 0;
}
