#include <iostream>
#define soa 10
using namespace std;

class Account
{
	int accountNumber;
	float balance;

	public:

	void setAccountNumber(int accountNumber){
		this->accountNumber = accountNumber;
	}
	void setBalance(float balance){
		this->balance = balance;
	}
	int getAccountNumber(){return accountNumber;}
	float getBalance(){return balance;}
};

void printArray(Account accounts[])
{
	cout<<endl<<"### Printing array elements ###"<<endl;
    for(int i=0; i<soa; i++)
    {
		cout<<"In ["<<i<<"] index:"<<endl;
        cout<<"Account Number: "<<accounts[i].getAccountNumber()<<endl;
		cout<<"Account Balance: "<<accounts[i].getBalance()<<endl;
    }
    cout<<endl;
}

void bubbleSortAN(Account accounts[])
{

{
    int accountNumber;

    cout<<"Enter array size: ";
    cin>>accountNumber;

    int arr[10];
    cout<<"Enter the value: ";

    for(int i=0; i<accountNumber; i++)
       {cin>>arr[i];}


    for(int i=1;i<accountNumber;++i)
       {
          for(int j=0;j<(accountNumber-i);++j)
          {

            if(arr[j]>arr[j+1])
             {
                   int a=arr[j];
                    arr[j]=arr[j+1];
                    arr[j+1]=a;
            }
          }



     cout<<"Bubble sort of the accounts: ";
     for(int i=0; i<accountNumber; i++)
     cout<<" "<<arr[i];
}
}
}

void bubbleSortB(Account accounts[])
{

{
    int balance;

    cout<<"Enter array size: ";
    cin>>balance;

    int arr[10];
    cout<<"Enter the value: ";

    for(int i=0; i<balance; i++)
       {cin>>arr[i];}


    for(int i=1;i<balance;++i)
{
          for(int j=0;j<(balance-i);++j)
          {

            if(arr[j]>arr[j+1])
             {
                int a=arr[j];
                arr[j]=arr[j+1];
                arr[j+1]=a;
             }
          }



      cout<<"Bubble sort of the balances: "<<endl;
      for(int i=0; i<balance; i++)
      cout<<" "<<arr[i];
}
}
}

int binarySearchAN(Account accounts[], int value)
{
	int position = -1;
{
    int arr[soa], value;
    int f_index = 0, l_index = soa-1;
    int pos = -1;

   cout<<"Enter the sorted elements: ";
   for(int i=0; i<soa; i++)
   {
        cin>>arr[i];
   }
   cout<<"Enter the value to search: ";
   cin>>value;

   while(f_index<= l_index)
   {
        int m_index = (f_index+l_index)/2;
        if(arr[m_index]<value)
        {
            f_index = m_index + 1;
        }
        else if(arr[m_index]>value)
        {
            l_index = m_index - 1;
        }
        else
        {
            pos = m_index;
            break;
        }
   }

   if(pos == -1)
   {
        cout<<value<<"Account Does NOT Exists"<<endl;
   }
   else
   {
        cout<<value<<"Account Found at ["<<pos<<"] position"<<endl;
   }
}

	return position;
}

int main()
{
	Account accounts[soa];

	for(int i=0; i<soa; i++)
	{
		int an;
		float b;

		cout<<"Enter the Account Number: ";
		cin>>an;
		cout<<"Enter the Balance: ";
		cin>>b;

		accounts[i].setAccountNumber(an);
		accounts[i].setBalance(b);
	}
	printArray(accounts);

	bubbleSortB(accounts);
	printArray(accounts);

	bubbleSortAN(accounts);
	printArray(accounts);

	int number;
	cout<<"Enter an Account Number to search : ";
	cin>>number;
	int position = binarySearchAN(accounts, number);

	if(position == -1)
	{
		cout<<number<<" Does NOT Exists"<<endl;
	}
	else
	{
		cout<<number<<" Exists in Index ["<<position<<"]."<<endl;
	}
	return 0;
}
