#include <iostream>

using namespace std;

int main()
{
    int soa; //soa means size of array//
    cout<<"Enter your size of array: "<<endl;
    cin>>soa;

    int arr[soa];

    cout<<"Enter array: "<<endl;

    for(int i=0;i<soa; i++)
    {
        cin>>arr[i];
    }

    int eve=0;
    int od=0;

     for(int i=0;i<soa; i++)
    {
        if(arr[i]%2==0)
        {
            eve++;
        }
        else if(arr[i]%2 != 0)
            {od++;}
    }


    int e[eve];
    int o[od];
    int ioe=0;   //ioe means Index of even//
    int ioo=0;  //ioo means Index of odd//

     for(int i=0;i<soa; i++)
    {
        if(arr[i]%2==0)
        {
            e[ioe] = arr[i];
            e[ioe]++;


        }
        else if(arr[i]%2 != 0)
            {
                o[ioo] = arr[i];
                o[ioo]++;


            }
    }

    cout<<"Even: "<<endl;

    for(int i = 0; i<soa; i++)
    {
        cout<<e[ioe]<<"  ";
    }
    cout<<endl;

    cout<<"ODD: "<<endl;

    for(int i = 0; i<soa; i++)
    {
        cout<<o[ioo]<<"  ";
    }
    cout<<endl;

}
