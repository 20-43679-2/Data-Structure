#include <iostream>
using namespace std;

int main()
{
   int n;
   cout<<"Enter the 2D array size: ";
   cin>>n;

   int arr[n-1][n-1];
   for(int i=0; i<n; i++)
{
       for(int j=0; j<n && i%2==0; j++)
    {
            if(j%2)
            {
                cout<<"row "<<i<<" column "<<j<<endl;
                cout<<"Enter array element: ";
                cin>>arr[i][j];
            }
    }
}

   cout<<"Output: "<<endl;
   for(int i=0; i<n; i++)
    {
       for(int j=0; j<n && i%2==0; j++)
            {
            if(j%2)
            {
                cout<<arr[i][j]<<" ";
            }
    }
   }
   return 0;
}
