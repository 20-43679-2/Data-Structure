#include <iostream>
using namespace std;

int main()
{
    int soa1, soa2;

    cout<<"Enter the Size of array 1: ";
    cout<<"Enter the Size of array 2: ";
    cin>>soa1>>soa2;


cout<<"Enter the value of array: "<<endl;
    int arr[soa1][soa2];

    for(int i=0; i<soa1; i++)
    {
        for(int j=0; j<soa2; j++)
    {
        cin>>arr[i][j];
    }
    }

}
