#include <iostream>
using namespace std;

int GetSmallestElement(int arr[], int n)

{
   int smallest = arr[0];
   for(int i=0; i<n; i++) {
      if(smallest>arr[i])
      {
         smallest=arr[i];
      }
   }
   return smallest;
}

int main()
{
   int n;
   cout<<"Enter the array size: "<<endl;
   cin>>n;

   int arr[n-1];

   for(int i=0; i<n; i++)
   {
    cout<<"Enter array element: "<<endl;
    cin>>arr[i];
   }

   int smallest = GetSmallestElement(arr, n);
   cout<<"Smallest Element is: "<<smallest;

   return 0;
}
