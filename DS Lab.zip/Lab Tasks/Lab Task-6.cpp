#include<iostream>
using namespace std;

struct Node
{
	int data;
	Node *nextNode;
};

Node *firstNode, *newNode, *currentNode, lastNode;
int n, head;

void printElements()
{
	currentNode = firstNode;

	while (currentNode != NULL)
	{
		cout<<currentNode->data<<"--->";
		currentNode = currentNode->nextNode;
	}
	cout<<endl;
}

void searchElement()
{
	int element;
	bool flag = false;

	cout<<"Enter the value of the element to search: ";
	cin>>element;

	currentNode = firstNode;

	while(currentNode != NULL)
	{
		if(currentNode->data == element)
		{
			flag = true;
			break;
		}
		else
		{
			currentNode = currentNode->nextNode;
		}
	}
	if(flag == true)
	{
		cout<<"Found"<<endl;
	}
	else
	{
		cout<<"Not Found"<<endl;
	}
}

void insertNodeAtFirstPosition(int num, Node * prev=NULL)
{
    Node *newNode = new Node;
    newNode -> data = num;
    newNode -> nextNode = NULL;


    if(prev==NULL)
    {
        firstNode = newNode;
        lastNode = newNode;
    }

    else
    {
        newNode->nextNode = firstNode;
        firstNode =newNode;
    }
}

void insertNodeAtLastPosition(int data)
{

       Node *newNode = new Node();
       newNode->data = data;
       newNode->nextNode = NULL;

    if(prev==NULL)
        {
        firstNode = newNode;
        lastNode = newNode;
        }
    else
        {
        lastNode -> newNode = newNode
        lastNode = newNode;
        }
}

void insertNodeSomewhereInTheMiddle(int temp, int data)
{
       Node *nextNode=new Node();
       nextNode->data=data;
       nextNode->nextNode=NULL;


        int i = 0;
        currentNode = firstNode;
        while (currentNode != NULL && i < temp)
        {
        i++;
        currentNode = currentNode->nextNode;
        }

        newNode -> nextNode = currentNode -> nextNode;
        currentNode -> nextNode = newNode;
}


void deleteNodeFromFirstPosition(int head)
{

   if(head==NULL)
         cout<<"List is already empty!"<<endl;
   else
{
  firstNode = firstNode->nextNode;
}
}

void deleteNodeFromLastPosition()
{
       currentNode = firstNode;
       while (currentNode -> nextNode != lastNode)
       {
        currentNode = currentNode->nextNode;
       }

        lastNode = currentNode;
        lastNode -> nextNode = NULL;
}


void deleteNodeSomewhereInTheMiddle(int value)
{
     int v = 0;
     currentNode = firstNode;
     while (currentNode != NULL && v < value - 1)
     {
      v++;
      currentNode = currentNode->nextNode;
     }

      currentNode -> nextNode = (currentNode -> nextNode)-> nextNode;
}

int main()
{
	cout<<"Enter the number of nodes for a linked list: ";
	cin>>n;

	for(int i = 1; i<=n; i++)
	{
		newNode = new (Node);

		int element;
		cout<<"Enter the element for node no. {"<<i<<"}: ";
		cin>>element;

		newNode->data = element;
		newNode->nextNode = NULL;

		if(firstNode == NULL)
		{
			firstNode = newNode;
			currentNode = newNode;
		}
		else
		{
			currentNode->nextNode = newNode;
			currentNode = newNode;
		}
	}

	printElements();
	searchElement();
}
