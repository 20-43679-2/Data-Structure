#include <iostream>
using namespace std;

int main()
{
      int n, i, j, temp, no_swap=0, comp=0;
      cout << "Please enter the size of an array: ";
      cin >> n;
      char array[n];
      cout<< "Please enter the elements of an array: ";

      for (i = 0; i < n; i++)
      {
          cin >> array[i];
      }


      cout<<"\nUnsorted array: ";

      for(int i = 0; i < n; i++)
      {
          cout << array[i] << " ";
      }
      cout << endl << endl;


      for (i = 1; i < n; i++)
      {
          j = i;
          while (j > 0)
          {
              comp++;
              if(array[j - 1] > array[j])
              {
                temp = array[j - 1];
                array[j - 1] = array[j];
                array[j] = temp;
                no_swap++;
              }

            j--;
          }
       }


    cout<<"Sorted Elements: ";
    for(i=0;i<n;i++)
    {
        cout<<array[i]<<" ";
    }
    cout << endl << endl;


    char value;
    int f_index = 0, l_index = 0;
    int pos = -1;


   cout<<"Enter the value to search: ";
   cin>>value;


   while(f_index<= l_index)
   {
        int m_index = (f_index+l_index)/2;

        if(array[m_index]<value)
        {
            f_index = m_index + 1;
        }
        else if(array[m_index]>value)
        {
            l_index = m_index - 1;
        }
        else if (array[m_index]== value)
        {
            pos = m_index;
            break;
        }
   }

 if(pos == -1)
   {
        cout<<value<<" Does NOT Exists"<<endl;
   }
   else
   {
        cout<<value<<" Found"<<endl;
   }

 return 0;
}
