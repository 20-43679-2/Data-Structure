#include <iostream>
using namespace std;

int main()
{
    int n, k, m;

    cout<<"Enter array size: ";
    cin>>n;

    int arr[n];
    cout<<"Enter the value: ";

    for(int i=0; i<n; i++){cin>>arr[i];}

    for(int i=0;i<n-1;i++)
    {
        m = arr[i];
        k=i;
        for(int j=i+1;j<n;j++)
        {
            if(m>arr[j])
            {
                m=arr[j];
                k=j;
            }
        }

        int a=arr[i];
        arr[i]=arr[k];
        arr[k]=a;


      }
      cout<<"Sorted array: ";
      for(int i=0; i<n; i++)
      {
        cout<<" "<<arr[i];
      }

}
