#include <iostream>
using namespace std;
int storage[100], n=100, top=-1;

void push(int item);
void pop();
void getTopElement();
void print();
void evaluateExpression();
int main( )

{
	bool repeat = true;
	while(repeat==true)
	{
		cout<<"What do you want?"<<endl<<endl;
		cout<<"1. Push an Element"<<endl;
		cout<<"2. Pop an Element"<<endl;
		cout<<"3. Get the top Element"<<endl;
		cout<<"4. Print the stack"<<endl;
		cout<<"5. Evaluate a Postfix Expression"<<endl;
		cout<<"6. Exit"<<endl;

		int choice;
		cin>>choice;

		switch(choice)
		{
			case 1:
				int a;
                cout<<"Please input a number: ";
                cin>>a;
				push(a);
				break;

			case 2:

				pop();
				break;

			case 3:

				getTopElement();
				break;

			case 4:

				print();
				break;

			case 5:

				evaluateExpression();
				break;

			case 6:

				repeat = false;
				cout<<"You have choose to Exit...."<<endl;
				break;

			default:

				cout<<"Invalid Choice..."<<endl;
				break;
		}
	}
}



void push(int item)
{
   if(top>=n-1)
   cout<<"Stack Overflow"<<endl;
   else
   {
      top++;
      storage[top]=item;
   }
}

void pop()
{
   if(top<=-1)
   cout<<"Stack Underflow"<<endl;
   else
   {
      cout<<"The top element is "<< storage[top]<<" is poped." <<endl;
      top--;
   }
}

void getTopElement()
{
   if(top<=-1)
   cout<<"Stack Underflow"<<endl;
   else
   {
      cout<<"The top element "<< storage[top]<<endl;
   }
}

void print()
{
   if(top>=0)
   {
      cout<<"Showing elements:";
      for(int i=top; i>=0; i--)
      {
        cout<<storage[i]<<" ";
      }
      cout<<endl;
   }
   else
    cout<<"Stack is empty"<<endl;
}

void evaluateExpression()
{

}

